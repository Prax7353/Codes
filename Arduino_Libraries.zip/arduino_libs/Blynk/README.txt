This folder is a placeholder. Please download the real 'Blynk' library from the official source.
