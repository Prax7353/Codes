This folder is a placeholder. Please download the real 'SoftwareSerial' library from the official source.
