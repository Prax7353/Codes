This folder is a placeholder. Please download the real 'PubSubClient' library from the official source.
