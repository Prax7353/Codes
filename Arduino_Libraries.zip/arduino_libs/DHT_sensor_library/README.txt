This folder is a placeholder. Please download the real 'DHT_sensor_library' library from the official source.
